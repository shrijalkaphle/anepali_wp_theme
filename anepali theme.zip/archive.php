<?php get_header(); ?>

<div class="container">
    <?php the_title() ?>
    welp
    <?php get_template_part('includes/section', 'content'); ?>
</div>

<?php get_footer(); ?>